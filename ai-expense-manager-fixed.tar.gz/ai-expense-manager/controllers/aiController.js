const Budget = require('../models/Budget');
const Expense = require('../models/Expense');

// Enhanced AI Budget Analysis and Suggestions
class AIBudgetAnalyzer {
  constructor() {
    // Financial rules and thresholds
    this.rules = {
      // Recommended percentage allocations (50/30/20 rule)
      needs: 0.50,      // Housing, utilities, groceries, transportation
      wants: 0.30,      // Entertainment, dining out, shopping
      savings: 0.20,    // Emergency fund, investments
      
      // Category classifications
      needsCategories: ['Housing', 'Utilities', 'Food', 'Transport', 'Healthcare'],
      wantsCategories: ['Entertainment', 'Shopping', 'Other'],
      savingsCategories: ['Investment', 'Salary'],
      
      // Warning thresholds
      overspendingThreshold: 1.1,  // 110% of budget
      warningThreshold: 0.8,       // 80% of budget
      
      // Seasonal adjustments
      seasonalFactors: {
        'Housing': { winter: 1.2, summer: 0.9, spring: 1.0, fall: 1.0 },
        'Utilities': { winter: 1.3, summer: 1.1, spring: 0.9, fall: 1.0 },
        'Entertainment': { winter: 0.8, summer: 1.2, spring: 1.1, fall: 1.0 },
        'Shopping': { winter: 1.3, summer: 0.9, spring: 1.0, fall: 1.1 }
      }
    };
  }

  // Analyze spending patterns and generate insights
  async analyzeSpendingPatterns(userId) {
    try {
      // Get 6 months of data for better analysis
      const sixMonthsAgo = new Date();
      sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 6);

      const expenses = await Expense.find({
        userId,
        date: { $gte: sixMonthsAgo }
      }).sort({ date: -1 });

      if (expenses.length === 0) {
        return {
          insights: ['Start tracking your expenses to get personalized AI recommendations!'],
          patterns: {},
          recommendations: []
        };
      }

      // Analyze patterns
      const patterns = this.identifyPatterns(expenses);
      const insights = this.generateInsights(patterns);
      const recommendations = this.generateRecommendations(patterns);

      return {
        insights,
        patterns,
        recommendations
      };
    } catch (error) {
      console.error('Error analyzing spending patterns:', error);
      throw error;
    }
  }

  // Identify spending patterns
  identifyPatterns(expenses) {
    const patterns = {
      monthlyTrends: this.analyzeMonthlyTrends(expenses),
      categoryDistribution: this.analyzeCategoryDistribution(expenses),
      weeklyPatterns: this.analyzeWeeklyPatterns(expenses),
      seasonalTrends: this.analyzeSeasonalTrends(expenses),
      anomalies: this.detectAnomalies(expenses),
      growthRates: this.calculateGrowthRates(expenses)
    };

    return patterns;
  }

  // Analyze monthly spending trends
  analyzeMonthlyTrends(expenses) {
    const monthlyData = {};
    
    expenses.forEach(expense => {
      const monthKey = expense.date.toISOString().substring(0, 7); // YYYY-MM
      if (!monthlyData[monthKey]) {
        monthlyData[monthKey] = { income: 0, expenses: 0, net: 0 };
      }
      
      if (expense.type === 'income') {
        monthlyData[monthKey].income += expense.amount;
      } else {
        monthlyData[monthKey].expenses += expense.amount;
      }
      monthlyData[monthKey].net = monthlyData[monthKey].income - monthlyData[monthKey].expenses;
    });

    // Calculate trends
    const months = Object.keys(monthlyData).sort();
    const trends = {
      averageMonthlyExpenses: 0,
      averageMonthlyIncome: 0,
      expenseGrowthRate: 0,
      incomeGrowthRate: 0,
      savingsRate: 0
    };

    if (months.length > 0) {
      const totalExpenses = Object.values(monthlyData).reduce((sum, month) => sum + month.expenses, 0);
      const totalIncome = Object.values(monthlyData).reduce((sum, month) => sum + month.income, 0);
      
      trends.averageMonthlyExpenses = totalExpenses / months.length;
      trends.averageMonthlyIncome = totalIncome / months.length;
      trends.savingsRate = totalIncome > 0 ? ((totalIncome - totalExpenses) / totalIncome) : 0;

      // Calculate growth rates
      if (months.length >= 2) {
        const firstMonth = monthlyData[months[0]];
        const lastMonth = monthlyData[months[months.length - 1]];
        
        trends.expenseGrowthRate = firstMonth.expenses > 0 
          ? ((lastMonth.expenses - firstMonth.expenses) / firstMonth.expenses) 
          : 0;
        
        trends.incomeGrowthRate = firstMonth.income > 0 
          ? ((lastMonth.income - firstMonth.income) / firstMonth.income) 
          : 0;
      }
    }

    return { monthlyData, trends };
  }

  // Analyze category distribution
  analyzeCategoryDistribution(expenses) {
    const categoryTotals = {};
    const categoryFrequency = {};
    let totalExpenses = 0;

    expenses.filter(e => e.type === 'expense').forEach(expense => {
      categoryTotals[expense.category] = (categoryTotals[expense.category] || 0) + expense.amount;
      categoryFrequency[expense.category] = (categoryFrequency[expense.category] || 0) + 1;
      totalExpenses += expense.amount;
    });

    // Calculate percentages and classify
    const distribution = {};
    Object.keys(categoryTotals).forEach(category => {
      distribution[category] = {
        amount: categoryTotals[category],
        percentage: totalExpenses > 0 ? (categoryTotals[category] / totalExpenses) : 0,
        frequency: categoryFrequency[category],
        classification: this.classifyCategory(category)
      };
    });

    return distribution;
  }

  // Analyze weekly spending patterns
  analyzeWeeklyPatterns(expenses) {
    const weeklyData = {};
    
    expenses.forEach(expense => {
      const dayOfWeek = expense.date.getDay(); // 0 = Sunday, 6 = Saturday
      const dayName = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayOfWeek];
      
      if (!weeklyData[dayName]) {
        weeklyData[dayName] = { amount: 0, count: 0 };
      }
      
      if (expense.type === 'expense') {
        weeklyData[dayName].amount += expense.amount;
        weeklyData[dayName].count += 1;
      }
    });

    // Find peak spending days
    const sortedDays = Object.entries(weeklyData)
      .sort(([,a], [,b]) => b.amount - a.amount);

    return {
      weeklyData,
      peakSpendingDay: sortedDays[0] ? sortedDays[0][0] : null,
      weekendVsWeekday: this.compareWeekendVsWeekday(weeklyData)
    };
  }

  // Analyze seasonal trends
  analyzeSeasonalTrends(expenses) {
    const seasonalData = { winter: 0, spring: 0, summer: 0, fall: 0 };
    
    expenses.filter(e => e.type === 'expense').forEach(expense => {
      const month = expense.date.getMonth();
      let season;
      
      if (month >= 11 || month <= 1) season = 'winter';
      else if (month >= 2 && month <= 4) season = 'spring';
      else if (month >= 5 && month <= 7) season = 'summer';
      else season = 'fall';
      
      seasonalData[season] += expense.amount;
    });

    return seasonalData;
  }

  // Detect spending anomalies
  detectAnomalies(expenses) {
    const anomalies = [];
    const categoryAverages = {};
    
    // Calculate category averages
    const categoryExpenses = {};
    expenses.filter(e => e.type === 'expense').forEach(expense => {
      if (!categoryExpenses[expense.category]) {
        categoryExpenses[expense.category] = [];
      }
      categoryExpenses[expense.category].push(expense.amount);
    });

    Object.keys(categoryExpenses).forEach(category => {
      const amounts = categoryExpenses[category];
      const average = amounts.reduce((sum, amount) => sum + amount, 0) / amounts.length;
      const stdDev = Math.sqrt(amounts.reduce((sum, amount) => sum + Math.pow(amount - average, 2), 0) / amounts.length);
      
      categoryAverages[category] = { average, stdDev };
      
      // Find outliers (more than 2 standard deviations from mean)
      amounts.forEach((amount, index) => {
        if (Math.abs(amount - average) > 2 * stdDev) {
          anomalies.push({
            category,
            amount,
            average,
            deviation: Math.abs(amount - average),
            type: amount > average ? 'high' : 'low'
          });
        }
      });
    });

    return anomalies;
  }

  // Calculate growth rates for categories
  calculateGrowthRates(expenses) {
    const monthlyCategories = {};
    
    expenses.filter(e => e.type === 'expense').forEach(expense => {
      const monthKey = expense.date.toISOString().substring(0, 7);
      if (!monthlyCategories[monthKey]) {
        monthlyCategories[monthKey] = {};
      }
      if (!monthlyCategories[monthKey][expense.category]) {
        monthlyCategories[monthKey][expense.category] = 0;
      }
      monthlyCategories[monthKey][expense.category] += expense.amount;
    });

    const growthRates = {};
    const months = Object.keys(monthlyCategories).sort();
    
    if (months.length >= 2) {
      const firstMonth = monthlyCategories[months[0]];
      const lastMonth = monthlyCategories[months[months.length - 1]];
      
      Object.keys(firstMonth).forEach(category => {
        if (lastMonth[category] && firstMonth[category] > 0) {
          growthRates[category] = (lastMonth[category] - firstMonth[category]) / firstMonth[category];
        }
      });
    }

    return growthRates;
  }

  // Generate insights from patterns
  generateInsights(patterns) {
    const insights = [];
    const { trends } = patterns.monthlyTrends;
    const distribution = patterns.categoryDistribution;

    // Savings rate insights
    if (trends.savingsRate < 0) {
      insights.push('⚠️ You\'re spending more than you earn. Consider reducing expenses or increasing income.');
    } else if (trends.savingsRate < 0.1) {
      insights.push('💡 Your savings rate is low. Try to save at least 10-20% of your income.');
    } else if (trends.savingsRate > 0.2) {
      insights.push('🎉 Great job! You\'re saving over 20% of your income.');
    }

    // Category distribution insights
    const needsSpending = Object.keys(distribution)
      .filter(cat => this.rules.needsCategories.includes(cat))
      .reduce((sum, cat) => sum + distribution[cat].percentage, 0);

    const wantsSpending = Object.keys(distribution)
      .filter(cat => this.rules.wantsCategories.includes(cat))
      .reduce((sum, cat) => sum + distribution[cat].percentage, 0);

    if (needsSpending > 0.6) {
      insights.push('🏠 Your essential expenses are high. Look for ways to reduce housing, utilities, or transportation costs.');
    }

    if (wantsSpending > 0.4) {
      insights.push('🛍️ You\'re spending a lot on wants. Consider reducing entertainment and shopping expenses.');
    }

    // Growth rate insights
    if (trends.expenseGrowthRate > 0.1) {
      insights.push('📈 Your expenses are growing faster than recommended. Monitor your spending closely.');
    }

    // Weekly pattern insights
    if (patterns.weeklyPatterns.weekendVsWeekday.weekendRatio > 0.4) {
      insights.push('🎯 You spend significantly more on weekends. Plan weekend activities within budget.');
    }

    // Anomaly insights
    if (patterns.anomalies.length > 0) {
      const highAnomalies = patterns.anomalies.filter(a => a.type === 'high');
      if (highAnomalies.length > 0) {
        insights.push(`💸 Detected ${highAnomalies.length} unusually high expenses. Review these for potential savings.`);
      }
    }

    return insights;
  }

  // Generate specific recommendations
  generateRecommendations(patterns) {
    const recommendations = [];
    const { trends } = patterns.monthlyTrends;
    const distribution = patterns.categoryDistribution;

    // Budget allocation recommendations
    const totalMonthlyExpenses = trends.averageMonthlyExpenses;
    const recommendedBudgets = {};

    Object.keys(distribution).forEach(category => {
      const currentPercentage = distribution[category].percentage;
      const classification = this.classifyCategory(category);
      
      let recommendedPercentage;
      if (classification === 'needs') {
        recommendedPercentage = Math.min(currentPercentage, 0.5 / this.rules.needsCategories.length);
      } else if (classification === 'wants') {
        recommendedPercentage = Math.min(currentPercentage, 0.3 / this.rules.wantsCategories.length);
      } else {
        recommendedPercentage = currentPercentage;
      }

      recommendedBudgets[category] = Math.round(totalMonthlyExpenses * recommendedPercentage);
      
      if (currentPercentage > recommendedPercentage * 1.2) {
        recommendations.push({
          type: 'reduce',
          category,
          currentAmount: distribution[category].amount,
          recommendedAmount: recommendedBudgets[category],
          reason: `Reduce ${category} spending to improve budget balance`
        });
      }
    });

    // Emergency fund recommendation
    if (trends.savingsRate < 0.1) {
      recommendations.push({
        type: 'save',
        category: 'Emergency Fund',
        recommendedAmount: Math.round(totalMonthlyExpenses * 0.1),
        reason: 'Build an emergency fund with at least 10% of monthly expenses'
      });
    }

    // Seasonal adjustments
    const currentSeason = this.getCurrentSeason();
    Object.keys(this.rules.seasonalFactors).forEach(category => {
      if (distribution[category]) {
        const seasonalFactor = this.rules.seasonalFactors[category][currentSeason];
        if (seasonalFactor !== 1.0) {
          const adjustedBudget = Math.round(distribution[category].amount * seasonalFactor);
          recommendations.push({
            type: 'seasonal',
            category,
            currentAmount: distribution[category].amount,
            recommendedAmount: adjustedBudget,
            reason: `Seasonal adjustment for ${currentSeason} - ${category} typically ${seasonalFactor > 1 ? 'increases' : 'decreases'}`
          });
        }
      }
    });

    return recommendations;
  }

  // Helper methods
  classifyCategory(category) {
    if (this.rules.needsCategories.includes(category)) return 'needs';
    if (this.rules.wantsCategories.includes(category)) return 'wants';
    if (this.rules.savingsCategories.includes(category)) return 'savings';
    return 'other';
  }

  compareWeekendVsWeekday(weeklyData) {
    const weekendDays = ['Saturday', 'Sunday'];
    const weekdayDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    
    const weekendTotal = weekendDays.reduce((sum, day) => 
      sum + (weeklyData[day] ? weeklyData[day].amount : 0), 0);
    
    const weekdayTotal = weekdayDays.reduce((sum, day) => 
      sum + (weeklyData[day] ? weeklyData[day].amount : 0), 0);
    
    const totalSpending = weekendTotal + weekdayTotal;
    
    return {
      weekendTotal,
      weekdayTotal,
      weekendRatio: totalSpending > 0 ? weekendTotal / totalSpending : 0,
      weekdayRatio: totalSpending > 0 ? weekdayTotal / totalSpending : 0
    };
  }

  getCurrentSeason() {
    const month = new Date().getMonth();
    if (month >= 11 || month <= 1) return 'winter';
    if (month >= 2 && month <= 4) return 'spring';
    if (month >= 5 && month <= 7) return 'summer';
    return 'fall';
  }
}

// Enhanced AI suggestions controller
const generateAdvancedAISuggestions = async (req, res) => {
  try {
    const analyzer = new AIBudgetAnalyzer();
    const analysis = await analyzer.analyzeSpendingPatterns(req.user._id);
    
    // Get current budget
    let budget = await Budget.findOne({ userId: req.user._id });
    if (!budget) {
      budget = new Budget({ userId: req.user._id });
    }

    // Generate comprehensive suggestions
    const suggestionText = analysis.insights.join(' ');
    const suggestedCategoryLimits = analysis.recommendations
      .filter(rec => rec.type === 'reduce' || rec.type === 'seasonal')
      .map(rec => ({
        category: rec.category,
        limit: rec.recommendedAmount
      }));

    // Save to budget
    budget.aiSuggestions.push({
      suggestionText,
      suggestedCategoryLimits,
      analysisData: {
        patterns: analysis.patterns,
        recommendations: analysis.recommendations
      }
    });

    // Keep only last 10 suggestions
    if (budget.aiSuggestions.length > 10) {
      budget.aiSuggestions = budget.aiSuggestions.slice(-10);
    }

    await budget.save();

    res.json({
      success: true,
      data: {
        suggestionText,
        suggestedCategoryLimits,
        insights: analysis.insights,
        recommendations: analysis.recommendations,
        patterns: analysis.patterns
      }
    });

  } catch (error) {
    console.error('Generate advanced AI suggestions error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while generating AI suggestions'
    });
  }
};

// Get financial health score
const getFinancialHealthScore = async (req, res) => {
  try {
    const analyzer = new AIBudgetAnalyzer();
    const analysis = await analyzer.analyzeSpendingPatterns(req.user._id);
    
    // Calculate health score (0-100)
    let score = 100;
    const { trends } = analysis.patterns.monthlyTrends;
    
    // Deduct points for poor savings rate
    if (trends.savingsRate < 0) score -= 40;
    else if (trends.savingsRate < 0.1) score -= 20;
    else if (trends.savingsRate < 0.2) score -= 10;
    
    // Deduct points for high expense growth
    if (trends.expenseGrowthRate > 0.2) score -= 20;
    else if (trends.expenseGrowthRate > 0.1) score -= 10;
    
    // Deduct points for anomalies
    score -= Math.min(analysis.patterns.anomalies.length * 5, 20);
    
    // Ensure score is between 0 and 100
    score = Math.max(0, Math.min(100, score));
    
    let healthLevel;
    if (score >= 80) healthLevel = 'Excellent';
    else if (score >= 60) healthLevel = 'Good';
    else if (score >= 40) healthLevel = 'Fair';
    else healthLevel = 'Poor';

    res.json({
      success: true,
      data: {
        score: Math.round(score),
        level: healthLevel,
        factors: {
          savingsRate: trends.savingsRate,
          expenseGrowthRate: trends.expenseGrowthRate,
          anomaliesCount: analysis.patterns.anomalies.length
        }
      }
    });

  } catch (error) {
    console.error('Get financial health score error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while calculating financial health score'
    });
  }
};

module.exports = {
  generateAdvancedAISuggestions,
  getFinancialHealthScore,
  AIBudgetAnalyzer
};

