const mongoose = require('mongoose');

const budgetSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
    unique: true
  },
  monthlyBudget: {
    type: Number,
    min: 0,
    default: 0
  },
  categoryBudgets: [{
    category: {
      type: String,
      required: true,
      enum: ['Food', 'Transport', 'Housing', 'Entertainment', 'Utilities', 'Shopping', 'Healthcare', 'Education', 'Other']
    },
    limit: {
      type: Number,
      min: 0,
      required: true
    }
  }],
  aiSuggestions: [{
    date: {
      type: Date,
      default: Date.now
    },
    suggestionText: {
      type: String,
      required: true
    },
    suggestedCategoryLimits: [{
      category: String,
      limit: Number
    }]
  }],
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

// Update the updatedAt field before saving
budgetSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});

module.exports = mongoose.model('Budget', budgetSchema);

