const { body, validationResult } = require('express-validator');

// Validation error handler
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array()
    });
  }
  next();
};

// User registration validation
const validateRegistration = [
  body('username')
    .trim()
    .isLength({ min: 3, max: 30 })
    .withMessage('Username must be between 3 and 30 characters')
    .matches(/^[a-zA-Z0-9_]+$/)
    .withMessage('Username can only contain letters, numbers, and underscores'),
  
  body('email')
    .trim()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .isLength({ min: 6 })
    .withMessage('Password must be at least 6 characters long')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/)
    .withMessage('Password must contain at least one lowercase letter, one uppercase letter, and one number'),
  
  body('confirmPassword')
    .custom((value, { req }) => {
      if (value !== req.body.password) {
        throw new Error('Password confirmation does not match password');
      }
      return true;
    }),
  
  handleValidationErrors
];

// User login validation
const validateLogin = [
  body('email')
    .trim()
    .isEmail()
    .normalizeEmail()
    .withMessage('Please provide a valid email address'),
  
  body('password')
    .notEmpty()
    .withMessage('Password is required'),
  
  handleValidationErrors
];

// Expense validation
const validateExpense = [
  body('amount')
    .isFloat({ min: 0.01 })
    .withMessage('Amount must be a positive number'),
  
  body('category')
    .isIn(['Food', 'Transport', 'Housing', 'Entertainment', 'Utilities', 'Shopping', 'Healthcare', 'Education', 'Salary', 'Investment', 'Other'])
    .withMessage('Invalid category'),
  
  body('type')
    .isIn(['expense', 'income'])
    .withMessage('Type must be either expense or income'),
  
  body('description')
    .optional()
    .trim()
    .isLength({ max: 500 })
    .withMessage('Description cannot exceed 500 characters'),
  
  body('date')
    .optional()
    .isISO8601()
    .withMessage('Date must be in valid ISO format'),
  
  handleValidationErrors
];

// Budget validation
const validateBudget = [
  body('monthlyBudget')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Monthly budget must be a positive number'),
  
  body('categoryBudgets')
    .optional()
    .isArray()
    .withMessage('Category budgets must be an array'),
  
  body('categoryBudgets.*.category')
    .optional()
    .isIn(['Food', 'Transport', 'Housing', 'Entertainment', 'Utilities', 'Shopping', 'Healthcare', 'Education', 'Other'])
    .withMessage('Invalid category in budget'),
  
  body('categoryBudgets.*.limit')
    .optional()
    .isFloat({ min: 0 })
    .withMessage('Budget limit must be a positive number'),
  
  handleValidationErrors
];

// Sanitize input to prevent XSS
const sanitizeInput = (req, res, next) => {
  // Basic XSS prevention - remove script tags and javascript: protocols
  const sanitize = (obj) => {
    for (let key in obj) {
      if (typeof obj[key] === 'string') {
        obj[key] = obj[key]
          .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
          .replace(/javascript:/gi, '')
          .replace(/on\w+\s*=/gi, '');
      } else if (typeof obj[key] === 'object' && obj[key] !== null) {
        sanitize(obj[key]);
      }
    }
  };

  if (req.body) sanitize(req.body);
  if (req.query) sanitize(req.query);
  if (req.params) sanitize(req.params);
  
  next();
};

module.exports = {
  validateRegistration,
  validateLogin,
  validateExpense,
  validateBudget,
  sanitizeInput,
  handleValidationErrors
};

