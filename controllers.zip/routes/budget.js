const express = require('express');
const router = express.Router();

const budgetController = require('../controllers/budgetController');
const { authenticateToken } = require('../middleware/auth');
const { validateBudget, sanitizeInput } = require('../middleware/validation');

// All routes are protected
router.use(authenticateToken);

// @route   GET /api/budget
// @desc    Get user's budget
// @access  Private
router.get('/', budgetController.getBudget);

// @route   PUT /api/budget
// @desc    Update user's budget
// @access  Private
router.put('/', sanitizeInput, validateBudget, budgetController.updateBudget);

// @route   GET /api/budget/analysis
// @desc    Get budget analysis
// @access  Private
router.get('/analysis', budgetController.getBudgetAnalysis);

// @route   POST /api/budget/ai-suggestions
// @desc    Generate AI budget suggestions
// @access  Private
router.post('/ai-suggestions', budgetController.generateAISuggestions);

// @route   GET /api/budget/ai-suggestions
// @desc    Get AI suggestion history
// @access  Private
router.get('/ai-suggestions', budgetController.getAISuggestionHistory);

module.exports = router;

