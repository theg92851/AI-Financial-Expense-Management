const express = require('express');
const router = express.Router();

const expenseController = require('../controllers/expenseController');
const { authenticateToken } = require('../middleware/auth');
const { validateExpense, sanitizeInput } = require('../middleware/validation');

// All routes are protected
router.use(authenticateToken);

// @route   GET /api/expenses
// @desc    Get all expenses for user
// @access  Private
router.get('/', expenseController.getExpenses);

// @route   GET /api/expenses/stats
// @desc    Get expense statistics
// @access  Private
router.get('/stats', expenseController.getExpenseStats);

// @route   GET /api/expenses/:id
// @desc    Get single expense
// @access  Private
router.get('/:id', expenseController.getExpense);

// @route   POST /api/expenses
// @desc    Create new expense
// @access  Private
router.post('/', sanitizeInput, validateExpense, expenseController.createExpense);

// @route   PUT /api/expenses/:id
// @desc    Update expense
// @access  Private
router.put('/:id', sanitizeInput, validateExpense, expenseController.updateExpense);

// @route   DELETE /api/expenses/:id
// @desc    Delete expense
// @access  Private
router.delete('/:id', expenseController.deleteExpense);

module.exports = router;

