// Authentication JavaScript
document.addEventListener('DOMContentLoaded', function() {
    // Check if user is already authenticated
    checkAuthStatus();

    // Initialize forms
    initializeForms();

    // Initialize password strength checker
    initializePasswordStrength();

    // Check for URL parameters (OAuth errors, etc.)
    checkURLParameters();
});

// Check authentication status
async function checkAuthStatus() {
    try {
        const token = localStorage.getItem('token') || getCookie('token');
        if (!token) return;

        const response = await fetch('/api/auth/me', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            // User is authenticated, redirect to dashboard
            window.location.href = '/dashboard';
        } else {
            // Token is invalid, remove it
            localStorage.removeItem('token');
            deleteCookie('token');
        }
    } catch (error) {
        console.error('Error checking auth status:', error);
    }
}

// Initialize forms
function initializeForms() {
    const loginForm = document.getElementById('loginForm');
    const registerForm = document.getElementById('registerForm');

    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }

    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
}

// Handle login form submission
async function handleLogin(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const loginBtn = document.getElementById('loginBtn');
    const alert = document.getElementById('alert');

    // Show loading state
    setLoadingState(loginBtn, true);
    hideAlert(alert);

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                email: formData.get('email'),
                password: formData.get('password')
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Store token
            localStorage.setItem('token', data.token);
            
            // Show success message
            showAlert(alert, 'Login successful! Redirecting...', 'success');
            
            // Redirect to dashboard
            setTimeout(() => {
                window.location.href = '/dashboard';
            }, 1000);
        } else {
            // Show error message
            showAlert(alert, data.message || 'Login failed', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showAlert(alert, 'Network error. Please try again.', 'error');
    } finally {
        setLoadingState(loginBtn, false);
    }
}

// Handle register form submission
async function handleRegister(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const registerBtn = document.getElementById('registerBtn');
    const alert = document.getElementById('alert');

    // Validate passwords match
    const password = formData.get('password');
    const confirmPassword = formData.get('confirmPassword');
    
    if (password !== confirmPassword) {
        showAlert(alert, 'Passwords do not match', 'error');
        return;
    }

    // Show loading state
    setLoadingState(registerBtn, true);
    hideAlert(alert);

    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                username: formData.get('username'),
                email: formData.get('email'),
                password: password
            })
        });

        const data = await response.json();

        if (response.ok) {
            // Store token
            localStorage.setItem('token', data.token);
            
            // Show success message
            showAlert(alert, 'Registration successful! Redirecting...', 'success');
            
            // Redirect to dashboard
            setTimeout(() => {
                window.location.href = '/dashboard';
            }, 1000);
        } else {
            // Show error message
            if (data.errors && Array.isArray(data.errors)) {
                const errorMessages = data.errors.map(err => err.msg).join(', ');
                showAlert(alert, errorMessages, 'error');
            } else {
                showAlert(alert, data.message || 'Registration failed', 'error');
            }
        }
    } catch (error) {
        console.error('Registration error:', error);
        showAlert(alert, 'Network error. Please try again.', 'error');
    } finally {
        setLoadingState(registerBtn, false);
    }
}

// Initialize password strength checker
function initializePasswordStrength() {
    const passwordInput = document.getElementById('password');
    const strengthIndicator = document.getElementById('passwordStrength');

    if (passwordInput && strengthIndicator) {
        passwordInput.addEventListener('input', function() {
            const password = this.value;
            const strength = calculatePasswordStrength(password);
            updatePasswordStrengthUI(strengthIndicator, strength);
        });
    }
}

// Calculate password strength
function calculatePasswordStrength(password) {
    let score = 0;
    let feedback = [];

    // Length check
    if (password.length >= 8) {
        score += 25;
    } else {
        feedback.push('At least 8 characters');
    }

    // Uppercase check
    if (/[A-Z]/.test(password)) {
        score += 25;
    } else {
        feedback.push('One uppercase letter');
    }

    // Lowercase check
    if (/[a-z]/.test(password)) {
        score += 25;
    } else {
        feedback.push('One lowercase letter');
    }

    // Number check
    if (/\d/.test(password)) {
        score += 25;
    } else {
        feedback.push('One number');
    }

    // Special character bonus
    if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) {
        score += 10;
    }

    return {
        score: Math.min(score, 100),
        feedback: feedback
    };
}

// Update password strength UI
function updatePasswordStrengthUI(strengthIndicator, strength) {
    const strengthFill = strengthIndicator.querySelector('.strength-fill');
    const strengthText = strengthIndicator.querySelector('.strength-text');

    strengthFill.style.width = `${strength.score}%`;

    if (strength.score < 50) {
        strengthFill.style.backgroundColor = '#ef4444';
        strengthText.textContent = 'Weak password';
        strengthText.style.color = '#ef4444';
    } else if (strength.score < 75) {
        strengthFill.style.backgroundColor = '#f59e0b';
        strengthText.textContent = 'Medium password';
        strengthText.style.color = '#f59e0b';
    } else {
        strengthFill.style.backgroundColor = '#10b981';
        strengthText.textContent = 'Strong password';
        strengthText.style.color = '#10b981';
    }

    if (strength.feedback.length > 0) {
        strengthText.textContent += ` (Need: ${strength.feedback.join(', ')})`;
    }
}

// Toggle password visibility
function togglePassword(inputId) {
    const input = document.getElementById(inputId);
    const toggle = input.parentElement.querySelector('.password-toggle i');

    if (input.type === 'password') {
        input.type = 'text';
        toggle.classList.remove('fa-eye');
        toggle.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        toggle.classList.remove('fa-eye-slash');
        toggle.classList.add('fa-eye');
    }
}

// Check URL parameters for errors
function checkURLParameters() {
    const urlParams = new URLSearchParams(window.location.search);
    const error = urlParams.get('error');
    const alert = document.getElementById('alert');

    if (error && alert) {
        let message = '';
        switch (error) {
            case 'oauth_failed':
                message = 'OAuth authentication failed. Please try again.';
                break;
            case 'oauth_error':
                message = 'An error occurred during OAuth authentication.';
                break;
            default:
                message = 'An error occurred. Please try again.';
        }
        showAlert(alert, message, 'error');
    }
}

// Utility functions
function setLoadingState(button, loading) {
    if (loading) {
        button.classList.add('loading');
        button.disabled = true;
    } else {
        button.classList.remove('loading');
        button.disabled = false;
    }
}

function showAlert(alertElement, message, type) {
    alertElement.textContent = message;
    alertElement.className = `alert ${type}`;
    alertElement.style.display = 'block';
    
    // Auto-hide success messages
    if (type === 'success') {
        setTimeout(() => {
            hideAlert(alertElement);
        }, 3000);
    }
}

function hideAlert(alertElement) {
    alertElement.style.display = 'none';
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}

function deleteCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
}

// Make togglePassword globally available
window.togglePassword = togglePassword;

