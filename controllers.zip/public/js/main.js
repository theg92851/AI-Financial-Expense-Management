// Main JavaScript for landing page
document.addEventListener('DOMContentLoaded', function() {
    // Mobile navigation toggle
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');

    if (hamburger) {
        hamburger.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            hamburger.classList.toggle('active');
        });
    }

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Animate elements on scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);

    // Observe feature cards
    document.querySelectorAll('.feature-card').forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(20px)';
        card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(card);
    });

    // Animate dashboard preview chart
    const chartBars = document.querySelectorAll('.bar');
    if (chartBars.length > 0) {
        setTimeout(() => {
            chartBars.forEach((bar, index) => {
                setTimeout(() => {
                    bar.style.transform = 'scaleY(1)';
                }, index * 100);
            });
        }, 1000);

        // Set initial state
        chartBars.forEach(bar => {
            bar.style.transformOrigin = 'bottom';
            bar.style.transform = 'scaleY(0)';
            bar.style.transition = 'transform 0.5s ease';
        });
    }

    // Add floating animation to background shapes
    const shapes = document.querySelectorAll('.bg-shape');
    shapes.forEach((shape, index) => {
        shape.style.animationDelay = `${index * 2}s`;
    });

    // Check authentication status
    checkAuthStatus();
});

// Check if user is authenticated
async function checkAuthStatus() {
    try {
        const token = localStorage.getItem('token') || getCookie('token');
        if (!token) return;

        const response = await fetch('/api/auth/me', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            // User is authenticated, update navigation
            updateNavForAuthenticatedUser();
        } else {
            // Token is invalid, remove it
            localStorage.removeItem('token');
            deleteCookie('token');
        }
    } catch (error) {
        console.error('Error checking auth status:', error);
    }
}

// Update navigation for authenticated users
function updateNavForAuthenticatedUser() {
    const navLinks = document.querySelector('.nav-links');
    if (navLinks) {
        navLinks.innerHTML = `
            <a href="#features">Features</a>
            <a href="#about">About</a>
            <a href="/dashboard" class="btn-primary">Dashboard</a>
        `;
    }
}

// Utility function to get cookie
function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}

// Utility function to delete cookie
function deleteCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
}

