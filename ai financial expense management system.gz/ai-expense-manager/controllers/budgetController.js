const Budget = require('../models/Budget');
const Expense = require('../models/Expense');

// Get user's budget
const getBudget = async (req, res) => {
  try {
    let budget = await Budget.findOne({ userId: req.user._id });

    if (!budget) {
      // Create default budget if none exists
      budget = new Budget({
        userId: req.user._id,
        monthlyBudget: 0,
        categoryBudgets: []
      });
      await budget.save();
    }

    res.json({
      success: true,
      data: budget
    });

  } catch (error) {
    console.error('Get budget error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching budget'
    });
  }
};

// Update user's budget
const updateBudget = async (req, res) => {
  try {
    const { monthlyBudget, categoryBudgets } = req.body;

    let budget = await Budget.findOne({ userId: req.user._id });

    if (!budget) {
      budget = new Budget({ userId: req.user._id });
    }

    if (monthlyBudget !== undefined) {
      budget.monthlyBudget = monthlyBudget;
    }

    if (categoryBudgets !== undefined) {
      budget.categoryBudgets = categoryBudgets;
    }

    await budget.save();

    res.json({
      success: true,
      message: 'Budget updated successfully',
      data: budget
    });

  } catch (error) {
    console.error('Update budget error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while updating budget'
    });
  }
};

// Get budget analysis
const getBudgetAnalysis = async (req, res) => {
  try {
    const budget = await Budget.findOne({ userId: req.user._id });

    if (!budget) {
      return res.status(404).json({
        success: false,
        message: 'Budget not found'
      });
    }

    // Get current month expenses
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthEnd = new Date(now.getFullYear(), now.getMonth() + 1, 0);

    const monthlyExpenses = await Expense.aggregate([
      {
        $match: {
          userId: req.user._id,
          type: 'expense',
          date: { $gte: monthStart, $lte: monthEnd }
        }
      },
      {
        $group: {
          _id: '$category',
          spent: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      }
    ]);

    // Calculate total monthly spending
    const totalSpent = monthlyExpenses.reduce((sum, expense) => sum + expense.spent, 0);

    // Analyze category budgets
    const categoryAnalysis = budget.categoryBudgets.map(categoryBudget => {
      const expenseData = monthlyExpenses.find(exp => exp._id === categoryBudget.category);
      const spent = expenseData ? expenseData.spent : 0;
      const remaining = categoryBudget.limit - spent;
      const percentageUsed = categoryBudget.limit > 0 ? (spent / categoryBudget.limit) * 100 : 0;

      return {
        category: categoryBudget.category,
        budgeted: categoryBudget.limit,
        spent,
        remaining,
        percentageUsed: Math.round(percentageUsed * 100) / 100,
        status: percentageUsed > 100 ? 'over' : percentageUsed > 80 ? 'warning' : 'good'
      };
    });

    // Overall budget analysis
    const overallAnalysis = {
      monthlyBudget: budget.monthlyBudget,
      totalSpent,
      remaining: budget.monthlyBudget - totalSpent,
      percentageUsed: budget.monthlyBudget > 0 ? (totalSpent / budget.monthlyBudget) * 100 : 0
    };

    overallAnalysis.status = overallAnalysis.percentageUsed > 100 ? 'over' : 
                            overallAnalysis.percentageUsed > 80 ? 'warning' : 'good';

    res.json({
      success: true,
      data: {
        overall: overallAnalysis,
        categories: categoryAnalysis,
        period: {
          start: monthStart,
          end: monthEnd
        }
      }
    });

  } catch (error) {
    console.error('Get budget analysis error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while analyzing budget'
    });
  }
};

// Generate AI budget suggestions
const generateAISuggestions = async (req, res) => {
  try {
    const budget = await Budget.findOne({ userId: req.user._id });

    if (!budget) {
      return res.status(404).json({
        success: false,
        message: 'Budget not found'
      });
    }

    // Get last 3 months of expense data
    const now = new Date();
    const threeMonthsAgo = new Date(now.getFullYear(), now.getMonth() - 3, 1);

    const expenseHistory = await Expense.aggregate([
      {
        $match: {
          userId: req.user._id,
          type: 'expense',
          date: { $gte: threeMonthsAgo }
        }
      },
      {
        $group: {
          _id: {
            category: '$category',
            month: { $month: '$date' },
            year: { $year: '$date' }
          },
          total: { $sum: '$amount' },
          count: { $sum: 1 }
        }
      },
      {
        $group: {
          _id: '$_id.category',
          monthlyAverages: { $avg: '$total' },
          totalTransactions: { $sum: '$count' }
        }
      }
    ]);

    // Generate AI suggestions based on spending patterns
    const suggestions = [];
    let suggestedCategoryLimits = [];

    expenseHistory.forEach(categoryData => {
      const category = categoryData._id;
      const avgMonthlySpending = categoryData.monthlyAverages;
      
      // Find current budget for this category
      const currentBudget = budget.categoryBudgets.find(cb => cb.category === category);
      const currentLimit = currentBudget ? currentBudget.limit : 0;

      // Suggest budget based on average spending + 10% buffer
      const suggestedLimit = Math.ceil(avgMonthlySpending * 1.1);

      suggestedCategoryLimits.push({
        category,
        limit: suggestedLimit
      });

      // Generate specific suggestions
      if (currentLimit === 0) {
        suggestions.push(`Set a budget of $${suggestedLimit} for ${category} based on your average spending.`);
      } else if (avgMonthlySpending > currentLimit) {
        suggestions.push(`Consider increasing your ${category} budget from $${currentLimit} to $${suggestedLimit}.`);
      } else if (avgMonthlySpending < currentLimit * 0.7) {
        const newLimit = Math.ceil(avgMonthlySpending * 1.05);
        suggestions.push(`You could reduce your ${category} budget from $${currentLimit} to $${newLimit} and allocate funds elsewhere.`);
        suggestedCategoryLimits = suggestedCategoryLimits.map(scl => 
          scl.category === category ? { ...scl, limit: newLimit } : scl
        );
      }
    });

    // Calculate suggested monthly budget
    const suggestedMonthlyBudget = suggestedCategoryLimits.reduce((sum, scl) => sum + scl.limit, 0);

    if (suggestions.length === 0) {
      suggestions.push('Your current budget allocation looks good based on your spending patterns!');
    }

    // Add general financial advice
    const totalAvgSpending = expenseHistory.reduce((sum, cat) => sum + cat.monthlyAverages, 0);
    if (totalAvgSpending > budget.monthlyBudget * 0.9) {
      suggestions.push('Consider the 50/30/20 rule: 50% for needs, 30% for wants, and 20% for savings.');
    }

    const suggestionText = suggestions.join(' ');

    // Save AI suggestion to budget
    budget.aiSuggestions.push({
      suggestionText,
      suggestedCategoryLimits
    });

    // Keep only last 10 suggestions
    if (budget.aiSuggestions.length > 10) {
      budget.aiSuggestions = budget.aiSuggestions.slice(-10);
    }

    await budget.save();

    res.json({
      success: true,
      data: {
        suggestionText,
        suggestedCategoryLimits,
        suggestedMonthlyBudget,
        basedOnMonths: 3
      }
    });

  } catch (error) {
    console.error('Generate AI suggestions error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while generating AI suggestions'
    });
  }
};

// Get AI suggestion history
const getAISuggestionHistory = async (req, res) => {
  try {
    const budget = await Budget.findOne({ userId: req.user._id });

    if (!budget) {
      return res.status(404).json({
        success: false,
        message: 'Budget not found'
      });
    }

    res.json({
      success: true,
      data: budget.aiSuggestions.sort((a, b) => new Date(b.date) - new Date(a.date))
    });

  } catch (error) {
    console.error('Get AI suggestion history error:', error);
    res.status(500).json({
      success: false,
      message: 'Server error while fetching AI suggestion history'
    });
  }
};

module.exports = {
  getBudget,
  updateBudget,
  getBudgetAnalysis,
  generateAISuggestions,
  getAISuggestionHistory
};

