const express = require('express');
const router = express.Router();

const { generateAdvancedAISuggestions, getFinancialHealthScore } = require('../controllers/aiController');
const { authenticateToken } = require('../middleware/auth');

// All routes are protected
router.use(authenticateToken);

// @route   POST /api/ai/advanced-suggestions
// @desc    Generate advanced AI budget suggestions with pattern analysis
// @access  Private
router.post('/advanced-suggestions', generateAdvancedAISuggestions);

// @route   GET /api/ai/financial-health
// @desc    Get financial health score and analysis
// @access  Private
router.get('/financial-health', getFinancialHealthScore);

module.exports = router;

