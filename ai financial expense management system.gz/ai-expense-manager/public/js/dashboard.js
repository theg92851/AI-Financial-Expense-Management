// Dashboard JavaScript
let currentUser = null;
let expenses = [];
let budget = null;
let charts = {};

document.addEventListener('DOMContentLoaded', function() {
    // Check authentication
    checkAuthentication();
    
    // Initialize dashboard
    initializeDashboard();
    
    // Initialize event listeners
    initializeEventListeners();
    
    // Load initial data
    loadDashboardData();
});

// Check authentication
async function checkAuthentication() {
    try {
        const token = localStorage.getItem('token') || getCookie('token');
        if (!token) {
            window.location.href = '/login';
            return;
        }

        const response = await fetch('/api/auth/me', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            currentUser = await response.json();
            updateUserInfo(currentUser.user);
        } else {
            localStorage.removeItem('token');
            deleteCookie('token');
            window.location.href = '/login';
        }
    } catch (error) {
        console.error('Authentication error:', error);
        window.location.href = '/login';
    }
}

// Initialize dashboard
function initializeDashboard() {
    // Set current date for expense form
    const today = new Date().toISOString().split('T')[0];
    const expenseDate = document.getElementById('expenseDate');
    if (expenseDate) {
        expenseDate.value = today;
    }

    // Initialize charts
    initializeCharts();
}

// Initialize event listeners
function initializeEventListeners() {
    // Navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', handleNavigation);
    });

    // Sidebar toggle
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', toggleSidebar);
    }

    // Logout
    const logoutBtn = document.getElementById('logoutBtn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', handleLogout);
    }

    // Add expense button
    const addExpenseBtn = document.getElementById('addExpenseBtn');
    if (addExpenseBtn) {
        addExpenseBtn.addEventListener('click', () => openExpenseModal());
    }

    // Expense form
    const expenseForm = document.getElementById('expenseForm');
    if (expenseForm) {
        expenseForm.addEventListener('submit', handleExpenseSubmit);
    }

    // Modal close buttons
    const closeExpenseModal = document.getElementById('closeExpenseModal');
    const cancelExpenseBtn = document.getElementById('cancelExpenseBtn');
    if (closeExpenseModal) {
        closeExpenseModal.addEventListener('click', closeModal);
    }
    if (cancelExpenseBtn) {
        cancelExpenseBtn.addEventListener('click', closeModal);
    }

    // Budget update
    const updateBudgetBtn = document.getElementById('updateBudgetBtn');
    if (updateBudgetBtn) {
        updateBudgetBtn.addEventListener('click', handleBudgetUpdate);
    }

    // AI insights
    const generateInsightsBtn = document.getElementById('generateInsightsBtn');
    if (generateInsightsBtn) {
        generateInsightsBtn.addEventListener('click', generateAIInsights);
    }

    // Filters
    const categoryFilter = document.getElementById('categoryFilter');
    const typeFilter = document.getElementById('typeFilter');
    const expenseSearch = document.getElementById('expenseSearch');
    
    if (categoryFilter) categoryFilter.addEventListener('change', filterExpenses);
    if (typeFilter) typeFilter.addEventListener('change', filterExpenses);
    if (expenseSearch) expenseSearch.addEventListener('input', debounce(filterExpenses, 300));

    // Chart period selector
    const trendPeriod = document.getElementById('trendPeriod');
    if (trendPeriod) {
        trendPeriod.addEventListener('change', updateTrendChart);
    }
}

// Handle navigation
function handleNavigation(e) {
    e.preventDefault();
    const section = e.target.dataset.section;
    if (section) {
        showSection(section);
        updateActiveNav(e.target);
    }
}

// Show section
function showSection(sectionName) {
    // Hide all sections
    document.querySelectorAll('.content-section').forEach(section => {
        section.classList.remove('active');
    });

    // Show target section
    const targetSection = document.getElementById(`${sectionName}-section`);
    if (targetSection) {
        targetSection.classList.add('active');
    }

    // Update page title
    updatePageTitle(sectionName);

    // Load section-specific data
    loadSectionData(sectionName);
}

// Update active navigation
function updateActiveNav(activeLink) {
    document.querySelectorAll('.nav-item').forEach(item => {
        item.classList.remove('active');
    });
    activeLink.closest('.nav-item').classList.add('active');
}

// Update page title
function updatePageTitle(section) {
    const titles = {
        dashboard: { title: 'Dashboard', subtitle: 'Welcome back! Here\'s your financial overview.' },
        expenses: { title: 'Expenses', subtitle: 'Manage and track your expenses and income.' },
        budget: { title: 'Budget', subtitle: 'Set and monitor your budget goals.' },
        'ai-insights': { title: 'AI Insights', subtitle: 'Get intelligent recommendations for your finances.' },
        reports: { title: 'Reports', subtitle: 'Analyze your financial data with detailed reports.' }
    };

    const titleData = titles[section] || { title: 'Dashboard', subtitle: 'Welcome back!' };
    
    document.getElementById('pageTitle').textContent = titleData.title;
    document.getElementById('pageSubtitle').textContent = titleData.subtitle;
}

// Load dashboard data
async function loadDashboardData() {
    try {
        await Promise.all([
            loadExpenses(),
            loadBudget(),
            loadExpenseStats()
        ]);
        
        updateDashboardStats();
        updateRecentTransactions();
        updateCharts();
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// Load section-specific data
function loadSectionData(section) {
    switch (section) {
        case 'expenses':
            loadExpensesTable();
            break;
        case 'budget':
            loadBudgetAnalysis();
            break;
        case 'ai-insights':
            loadAIInsights();
            break;
        case 'reports':
            // Reports are generated on demand
            break;
    }
}

// Load expenses
async function loadExpenses() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/expenses?limit=50', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            expenses = data.data.expenses;
            return data.data;
        }
    } catch (error) {
        console.error('Error loading expenses:', error);
    }
    return { expenses: [], summary: {} };
}

// Load budget
async function loadBudget() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/budget', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            budget = await response.json();
            return budget.data;
        }
    } catch (error) {
        console.error('Error loading budget:', error);
    }
    return null;
}

// Load expense statistics
async function loadExpenseStats() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/expenses/stats?period=month', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            return data.data;
        }
    } catch (error) {
        console.error('Error loading expense stats:', error);
    }
    return null;
}

// Update dashboard statistics
function updateDashboardStats() {
    const expenseData = expenses.reduce((acc, expense) => {
        if (expense.type === 'income') {
            acc.totalIncome += expense.amount;
        } else {
            acc.totalExpenses += expense.amount;
        }
        return acc;
    }, { totalIncome: 0, totalExpenses: 0 });

    const netSavings = expenseData.totalIncome - expenseData.totalExpenses;
    const budgetUsed = budget && budget.monthlyBudget > 0 
        ? (expenseData.totalExpenses / budget.monthlyBudget * 100).toFixed(1)
        : 0;

    // Update stat cards
    document.getElementById('totalIncome').textContent = formatCurrency(expenseData.totalIncome);
    document.getElementById('totalExpenses').textContent = formatCurrency(expenseData.totalExpenses);
    document.getElementById('netSavings').textContent = formatCurrency(netSavings);
    document.getElementById('budgetUsed').textContent = `${budgetUsed}%`;
}

// Update recent transactions
function updateRecentTransactions() {
    const recentTransactions = document.getElementById('recentTransactions');
    if (!recentTransactions) return;

    const recentExpenses = expenses.slice(0, 5);
    
    if (recentExpenses.length === 0) {
        recentTransactions.innerHTML = '<p class="text-center">No transactions yet. <a href="#" onclick="openExpenseModal()">Add your first expense</a></p>';
        return;
    }

    recentTransactions.innerHTML = recentExpenses.map(expense => `
        <div class="transaction-item">
            <div class="transaction-info">
                <div class="transaction-icon ${expense.type}">
                    <i class="fas ${getTransactionIcon(expense.category)}"></i>
                </div>
                <div class="transaction-details">
                    <h4>${expense.description || expense.category}</h4>
                    <p>${formatDate(expense.date)} • ${expense.category}</p>
                </div>
            </div>
            <div class="transaction-amount ${expense.type}">
                ${expense.type === 'income' ? '+' : '-'}${formatCurrency(expense.amount)}
            </div>
        </div>
    `).join('');
}

// Initialize charts
function initializeCharts() {
    // Trend chart
    const trendCtx = document.getElementById('trendChart');
    if (trendCtx) {
        charts.trend = new Chart(trendCtx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Expenses',
                    data: [],
                    borderColor: '#ef4444',
                    backgroundColor: 'rgba(239, 68, 68, 0.1)',
                    tension: 0.4
                }, {
                    label: 'Income',
                    data: [],
                    borderColor: '#10b981',
                    backgroundColor: 'rgba(16, 185, 129, 0.1)',
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'top',
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return formatCurrency(value);
                            }
                        }
                    }
                }
            }
        });
    }

    // Category chart
    const categoryCtx = document.getElementById('categoryChart');
    if (categoryCtx) {
        charts.category = new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: [
                        '#3b82f6', '#ef4444', '#10b981', '#f59e0b',
                        '#8b5cf6', '#06b6d4', '#84cc16', '#f97316',
                        '#ec4899', '#6b7280'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom',
                    }
                }
            }
        });
    }
}

// Update charts
function updateCharts() {
    updateTrendChart();
    updateCategoryChart();
}

// Update trend chart
async function updateTrendChart() {
    const period = document.getElementById('trendPeriod')?.value || 'month';
    
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`/api/expenses/stats?period=${period}`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok && charts.trend) {
            const data = await response.json();
            const dailyTrend = data.data.dailyTrend || [];

            const labels = dailyTrend.map(item => formatDate(item._id));
            const expenseData = dailyTrend.map(item => item.expenses);
            const incomeData = dailyTrend.map(item => item.income);

            charts.trend.data.labels = labels;
            charts.trend.data.datasets[0].data = expenseData;
            charts.trend.data.datasets[1].data = incomeData;
            charts.trend.update();
        }
    } catch (error) {
        console.error('Error updating trend chart:', error);
    }
}

// Update category chart
function updateCategoryChart() {
    if (!charts.category) return;

    const categoryTotals = expenses
        .filter(expense => expense.type === 'expense')
        .reduce((acc, expense) => {
            acc[expense.category] = (acc[expense.category] || 0) + expense.amount;
            return acc;
        }, {});

    const labels = Object.keys(categoryTotals);
    const data = Object.values(categoryTotals);

    charts.category.data.labels = labels;
    charts.category.data.datasets[0].data = data;
    charts.category.update();
}

// Handle expense form submission
async function handleExpenseSubmit(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const expenseId = document.getElementById('expenseId').value;
    const saveBtn = document.getElementById('saveExpenseBtn');

    setLoadingState(saveBtn, true);

    try {
        const token = localStorage.getItem('token');
        const url = expenseId ? `/api/expenses/${expenseId}` : '/api/expenses';
        const method = expenseId ? 'PUT' : 'POST';

        const response = await fetch(url, {
            method: method,
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                amount: parseFloat(formData.get('amount')),
                category: formData.get('category'),
                type: formData.get('type'),
                description: formData.get('description'),
                date: formData.get('date')
            })
        });

        if (response.ok) {
            closeModal();
            await loadDashboardData();
            showNotification(expenseId ? 'Expense updated successfully!' : 'Expense added successfully!', 'success');
        } else {
            const error = await response.json();
            showNotification(error.message || 'Failed to save expense', 'error');
        }
    } catch (error) {
        console.error('Error saving expense:', error);
        showNotification('Network error. Please try again.', 'error');
    } finally {
        setLoadingState(saveBtn, false);
    }
}

// Open expense modal
function openExpenseModal(expense = null) {
    const modal = document.getElementById('expenseModal');
    const form = document.getElementById('expenseForm');
    const title = document.getElementById('expenseModalTitle');

    if (expense) {
        // Edit mode
        title.textContent = 'Edit Expense';
        document.getElementById('expenseId').value = expense._id;
        document.getElementById('expenseAmount').value = expense.amount;
        document.getElementById('expenseCategory').value = expense.category;
        document.getElementById('expenseType').value = expense.type;
        document.getElementById('expenseDescription').value = expense.description || '';
        document.getElementById('expenseDate').value = expense.date.split('T')[0];
    } else {
        // Add mode
        title.textContent = 'Add Expense';
        form.reset();
        document.getElementById('expenseId').value = '';
        document.getElementById('expenseDate').value = new Date().toISOString().split('T')[0];
    }

    modal.classList.add('active');
}

// Close modal
function closeModal() {
    const modal = document.getElementById('expenseModal');
    modal.classList.remove('active');
}

// Load expenses table
async function loadExpensesTable() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/expenses?limit=20', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            updateExpensesTable(data.data.expenses);
        }
    } catch (error) {
        console.error('Error loading expenses table:', error);
    }
}

// Update expenses table
function updateExpensesTable(expenses) {
    const tbody = document.getElementById('expensesTableBody');
    if (!tbody) return;

    if (expenses.length === 0) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">No expenses found</td></tr>';
        return;
    }

    tbody.innerHTML = expenses.map(expense => `
        <tr>
            <td>${formatDate(expense.date)}</td>
            <td>${expense.description || '-'}</td>
            <td><span class="category-badge">${expense.category}</span></td>
            <td><span class="type-badge ${expense.type}">${expense.type}</span></td>
            <td>${formatCurrency(expense.amount)}</td>
            <td>
                <div class="action-buttons">
                    <button class="action-btn edit" onclick="editExpense('${expense._id}')">
                        <i class="fas fa-edit"></i>
                    </button>
                    <button class="action-btn delete" onclick="deleteExpense('${expense._id}')">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        </tr>
    `).join('');
}

// Edit expense
function editExpense(expenseId) {
    const expense = expenses.find(e => e._id === expenseId);
    if (expense) {
        openExpenseModal(expense);
    }
}

// Delete expense
async function deleteExpense(expenseId) {
    if (!confirm('Are you sure you want to delete this expense?')) {
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`/api/expenses/${expenseId}`, {
            method: 'DELETE',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            await loadDashboardData();
            showNotification('Expense deleted successfully!', 'success');
        } else {
            showNotification('Failed to delete expense', 'error');
        }
    } catch (error) {
        console.error('Error deleting expense:', error);
        showNotification('Network error. Please try again.', 'error');
    }
}

// Handle budget update
async function handleBudgetUpdate() {
    const monthlyBudgetInput = document.getElementById('monthlyBudgetInput');
    const monthlyBudget = parseFloat(monthlyBudgetInput.value);

    if (isNaN(monthlyBudget) || monthlyBudget < 0) {
        showNotification('Please enter a valid budget amount', 'error');
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/budget', {
            method: 'PUT',
            headers: {
                'Authorization': `Bearer ${token}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ monthlyBudget })
        });

        if (response.ok) {
            await loadBudget();
            updateDashboardStats();
            showNotification('Budget updated successfully!', 'success');
        } else {
            showNotification('Failed to update budget', 'error');
        }
    } catch (error) {
        console.error('Error updating budget:', error);
        showNotification('Network error. Please try again.', 'error');
    }
}

// Load budget analysis
async function loadBudgetAnalysis() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/budget/analysis', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            updateBudgetAnalysis(data.data);
        }
    } catch (error) {
        console.error('Error loading budget analysis:', error);
    }
}

// Update budget analysis
function updateBudgetAnalysis(analysis) {
    const budgetAnalysis = document.getElementById('budgetAnalysis');
    if (!budgetAnalysis) return;

    const { overall, categories } = analysis;

    budgetAnalysis.innerHTML = `
        <div class="budget-overview-card">
            <h4>Monthly Budget Overview</h4>
            <div class="budget-progress">
                <div class="progress-bar">
                    <div class="progress-fill ${overall.status}" style="width: ${Math.min(overall.percentageUsed, 100)}%"></div>
                </div>
                <div class="budget-details">
                    <span>Spent: ${formatCurrency(overall.totalSpent)} of ${formatCurrency(overall.monthlyBudget)}</span>
                    <span class="budget-status ${overall.status}">${overall.percentageUsed.toFixed(1)}% used</span>
                </div>
            </div>
        </div>
        
        <div class="category-analysis">
            <h4>Category Breakdown</h4>
            ${categories.map(cat => `
                <div class="category-item">
                    <div class="category-header">
                        <span class="category-name">${cat.category}</span>
                        <span class="category-amount">${formatCurrency(cat.spent)} / ${formatCurrency(cat.budgeted)}</span>
                    </div>
                    <div class="category-progress">
                        <div class="progress-bar">
                            <div class="progress-fill ${cat.status}" style="width: ${Math.min(cat.percentageUsed, 100)}%"></div>
                        </div>
                        <span class="category-status ${cat.status}">${cat.percentageUsed.toFixed(1)}%</span>
                    </div>
                </div>
            `).join('')}
        </div>
    `;
}

// Generate AI insights
async function generateAIInsights() {
    const generateBtn = document.getElementById('generateInsightsBtn');
    setLoadingState(generateBtn, true);

    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/budget/ai-suggestions', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            displayAIInsights(data.data);
            showNotification('AI insights generated successfully!', 'success');
        } else {
            showNotification('Failed to generate AI insights', 'error');
        }
    } catch (error) {
        console.error('Error generating AI insights:', error);
        showNotification('Network error. Please try again.', 'error');
    } finally {
        setLoadingState(generateBtn, false);
    }
}

// Load AI insights
async function loadAIInsights() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch('/api/budget/ai-suggestions', {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        if (response.ok) {
            const data = await response.json();
            displayAIInsightsHistory(data.data);
        }
    } catch (error) {
        console.error('Error loading AI insights:', error);
    }
}

// Display AI insights
function displayAIInsights(insights) {
    const container = document.getElementById('insightsContainer');
    if (!container) return;

    container.innerHTML = `
        <div class="insight-card">
            <div class="insight-header">
                <h4><i class="fas fa-robot"></i> Latest AI Recommendation</h4>
                <span class="insight-date">${formatDate(new Date())}</span>
            </div>
            <div class="insight-content">
                <p>${insights.suggestionText}</p>
                ${insights.suggestedCategoryLimits && insights.suggestedCategoryLimits.length > 0 ? `
                    <div class="suggested-limits">
                        <h5>Suggested Budget Limits:</h5>
                        ${insights.suggestedCategoryLimits.map(limit => `
                            <div class="limit-item">
                                <span>${limit.category}</span>
                                <span>${formatCurrency(limit.limit)}</span>
                            </div>
                        `).join('')}
                    </div>
                ` : ''}
            </div>
        </div>
    `;
}

// Display AI insights history
function displayAIInsightsHistory(insights) {
    const historyContainer = document.getElementById('insightsHistory');
    if (!historyContainer) return;

    if (insights.length === 0) {
        historyContainer.innerHTML = '<p>No previous insights available.</p>';
        return;
    }

    historyContainer.innerHTML = insights.map(insight => `
        <div class="insight-card">
            <div class="insight-header">
                <h5>AI Recommendation</h5>
                <span class="insight-date">${formatDate(insight.date)}</span>
            </div>
            <div class="insight-content">
                <p>${insight.suggestionText}</p>
            </div>
        </div>
    `).join('');
}

// Filter expenses
function filterExpenses() {
    const category = document.getElementById('categoryFilter')?.value || '';
    const type = document.getElementById('typeFilter')?.value || '';
    const search = document.getElementById('expenseSearch')?.value.toLowerCase() || '';

    const filteredExpenses = expenses.filter(expense => {
        const matchesCategory = !category || expense.category === category;
        const matchesType = !type || expense.type === type;
        const matchesSearch = !search || 
            expense.description?.toLowerCase().includes(search) ||
            expense.category.toLowerCase().includes(search);

        return matchesCategory && matchesType && matchesSearch;
    });

    updateExpensesTable(filteredExpenses);
}

// Toggle sidebar
function toggleSidebar() {
    const sidebar = document.querySelector('.sidebar');
    sidebar.classList.toggle('open');
}

// Handle logout
async function handleLogout() {
    try {
        const token = localStorage.getItem('token');
        await fetch('/api/auth/logout', {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });
    } catch (error) {
        console.error('Logout error:', error);
    } finally {
        localStorage.removeItem('token');
        deleteCookie('token');
        window.location.href = '/login';
    }
}

// Update user info
function updateUserInfo(user) {
    const userInfo = document.getElementById('userInfo');
    if (userInfo) {
        userInfo.querySelector('.user-name').textContent = user.username;
        userInfo.querySelector('.user-email').textContent = user.email;
    }
}

// Utility functions
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    }).format(amount);
}

function formatDate(date) {
    return new Date(date).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

function getTransactionIcon(category) {
    const icons = {
        'Food': 'fa-utensils',
        'Transport': 'fa-car',
        'Housing': 'fa-home',
        'Entertainment': 'fa-film',
        'Utilities': 'fa-bolt',
        'Shopping': 'fa-shopping-bag',
        'Healthcare': 'fa-heartbeat',
        'Education': 'fa-graduation-cap',
        'Salary': 'fa-money-bill-wave',
        'Investment': 'fa-chart-line',
        'Other': 'fa-ellipsis-h'
    };
    return icons[category] || 'fa-ellipsis-h';
}

function setLoadingState(button, loading) {
    if (loading) {
        button.classList.add('loading');
        button.disabled = true;
    } else {
        button.classList.remove('loading');
        button.disabled = false;
    }
}

function showNotification(message, type) {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
    `;

    // Add to page
    document.body.appendChild(notification);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentElement) {
            notification.remove();
        }
    }, 5000);
}

function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

function getCookie(name) {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop().split(';').shift();
    return null;
}

function deleteCookie(name) {
    document.cookie = `${name}=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;`;
}

// Make functions globally available
window.editExpense = editExpense;
window.deleteExpense = deleteExpense;
window.openExpenseModal = openExpenseModal;

